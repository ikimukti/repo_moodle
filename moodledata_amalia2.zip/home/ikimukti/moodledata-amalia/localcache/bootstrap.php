<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'zCU0pVbURYGoEaMr3L1DgrCQNiXk89hflocalhost';
$CFG->bootstraphash = '225045a5275e35ca52c3fc7b7d226e71';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
