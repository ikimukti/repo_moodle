<?php

class __Mustache_dda4d01e0ac849791ede0c6efa98f1f7 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '<span class="sr-only sr-only-focusable" data-region="jumpto" tabindex="-1"></span>';

        return $buffer;
    }
}
